
export type DashBoardData = {
    announcements: Announcement[];
    events: Event[];
    users: User[];
};

export interface Announcement {
    id: number;
    title: string;
    content: string;
    date: string;
  }
  
  export interface Event {
    id: number;
    title: string;
    description: string;
    date: string;
    location: string;
  }
  
  export enum UserType {
    SU = 'su',
    ADMIN = 'admin',
    USER = 'user',
  }
  
  export interface User {
    _id: string;
    email: string;
    firstName: string;
    lastName: string;
    userType: UserType;
  }
  